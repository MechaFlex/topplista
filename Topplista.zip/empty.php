<?php
    $fh = fopen( 'data.txt', 'w' );
    fclose($fh);
?>